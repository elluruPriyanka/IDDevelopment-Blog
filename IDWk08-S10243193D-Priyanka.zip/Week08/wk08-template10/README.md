# What to do?
- Simply open the rep in a new window or download to test it our on your machine
- Check each question in the google doc

[Google Doc Login with NP email] (https://docs.google.com/document/d/1hONHt9ICyrCjtaJZYdCIR-AjoynyxUcTFOupolRjjjM/edit?usp=sharing)