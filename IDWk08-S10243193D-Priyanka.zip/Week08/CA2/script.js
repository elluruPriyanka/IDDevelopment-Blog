/*
#TODO
Playing with inputs and jQuery selectors
Create a button that allows text to be changed from "Help Me" 
To **"Hello Interactive Developers"**

https://api.jquery.com/click/
https://www.w3schools.com/jquery/event_click.asp
https://api.jquery.com/on/
*/
$(document).ready(function(){
  $('#change').click(function(){
    $("#msg").html("Hello Interactive Developers");
  })
  });